import time
import os
import random
import re
import pymsgbox
import requests
import time
import sys
## once this whole tool is done move to creating a mass dorker that is generated with random words and random id number with word prefix
## such as id=1 id=checkout also randomly genrated filname such as youraccount.php add function to add permutation to that to so youraccount1.php
## make db checker so dosnt use the same dork twice


## MAYBE MAKE THIS WHOLE SCRIPT A TRY STATEMENT THEN WHEN IT FAILS ON LINE 18 OR 28 MOVE TO SQLMAP make a process that will grab last line and move it to dork.txt then removes last line from bigdork list so dosnt use same dork twice

with open('bigdork.txt', 'r') as f:
    lines = f.read().splitlines()
    last_line = lines[-1]
    print(last_line, file=open("dork.txt" , "a"))
    keyz = open("dork.txt" , 'r').readline()
    for lnk in keyz:
           b = os.system(f"""python3 search_engines_cli.py -e yahoo,aol,ask -q {keyz}""")
           print(b)
           ## grabs last line from bigdordork.txt and removes it so that it dosnt repeat
           lines = open("bigdork.txt", "r").readlines()
           del lines[-1]
           open("bigdork.txt", "w").writelines(lines)
           ## grabs last line from dork.txt list and removes it to get it ready for new round
           os.system("rm -rf dork.txt")
           os.system("python3 drainer.py")
